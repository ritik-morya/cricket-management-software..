package com.harsh.cms.dao;

public class Authentication {

}
