package com.harsh.cms.dao;

import com.harsh.cms.model.User;
import java.util.List;

public class UserDAO {

    public static User getUser(String userDetail, String userDetailType) {


        return null;
    }



}
