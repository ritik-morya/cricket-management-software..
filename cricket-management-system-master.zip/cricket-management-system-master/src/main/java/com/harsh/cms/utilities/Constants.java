package com.harsh.cms.utilities;

public class Constants {
    public static final String USER_DETAIL_TYPE_EMAIL = "EMAIL";
    public static final String USER_DETAIL_TYPE_USER_ID = "USER_ID";
    public static final String USER_DETAIL_TYPE_PHONE = "PHONE";

}
